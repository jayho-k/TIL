n = int(input())
# n2 = n
# for i in range(n):
#     n -= i
#     print(n)
#     n = n2

for i in range(n ,0, -1):
    print(i)